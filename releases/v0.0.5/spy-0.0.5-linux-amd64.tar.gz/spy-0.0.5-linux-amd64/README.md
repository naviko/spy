# spy

See what a program really does on your machine.

```
spy <executable> [args...]
```

Put `spy` in front of any command. The program runs exactly as it normally would, in your terminal, fully interactive. While it runs, spy records what it does with your disk and your network, and writes it to a log you can read, search, or feed into your own tools.

It is built for the moment you want to run something you do not fully trust yet: a new CLI, an AI coding agent, an installer, a script from the internet.

## What it records

For the program and every child process it starts:

- **Web traffic, decrypted.** Every HTTP and HTTPS request and response, with headers and full bodies, including streamed responses and WebSocket messages.
- **Network.** Every connection it makes or accepts, for any protocol, and DNS lookups. On macOS and Linux, the content sent and received too.
- **Disk.** Which files it opens, reads, writes, creates, renames, moves, copies, and deletes, and every permission or attribute change. File contents are not recorded.
- **Processes.** Every program it launches, with its arguments, and how each one exits.

What you type and what the program shows on screen are not recorded.

## Install

Download the archive for your system from the [Releases](https://github.com/naviko/spy/releases) page, unpack it, and put `spy` and `spyview` somewhere on your `PATH`.

| System | Archive |
|---|---|
| macOS, Apple silicon | `spy-<version>-macos-arm64.tar.gz` |
| macOS, Intel | `spy-<version>-macos-amd64.tar.gz` |
| Linux, x86-64 | `spy-<version>-linux-amd64.tar.gz` |
| Linux, ARM64 | `spy-<version>-linux-arm64.tar.gz` |
| Windows, x86-64 | `spy-<version>-windows-amd64.zip` |
| Windows, ARM64 | `spy-<version>-windows-arm64.zip` |

On macOS, if the system refuses to open a downloaded program, clear the download flag once:

```
xattr -d com.apple.quarantine spy spyview
```

## Quick start

```
spy curl -s https://example.com
```

On macOS, add `sudo` in front (see "What each system needs"). When the program exits, spy tells you where the log is:

```
spy: events written to spy-20261112-204927-fa204161.jsonl
```

Open it in the viewer:

```
spyview
```

## Usage

```
spy [flags] <executable> [args...]
```

Everything after the executable name belongs to the program. spy exits with the program's exit code.

```
spy npm install                      # log goes to ./spy-<timestamp>-<id>.jsonl
spy --events run.jsonl npm install   # choose the log file
spy --events - npm install | jq .    # live events on standard output
```

### Flags

| Flag | What it does |
|---|---|
| `--events <path>` | Where to write the log. Use `-` to stream events to standard output. Default: a new file in the current folder. |
| `--env` | Fallback for programs whose web traffic is not decrypted by default. See below. |
| `--cert` | Second fallback for the same case. See below. |
| `--config <path>` | Use this config file. |
| `--no-redact` | Record credentials exactly as sent. |
| `--version` | Print the version. `spyview --version` does the same for the viewer. |

### What each system needs

| System | How to run | Why |
|---|---|---|
| Linux | `spy <executable>` | Nothing extra is needed. |
| macOS | `sudo spy <executable>` | Apple requires administrator rights, and Full Disk Access for your terminal app (System Settings > Privacy & Security > Full Disk Access). The program you launch still runs as you, and the log belongs to you. Use `sudo -E` to keep your shell's environment, such as API keys. |
| Windows | `spy <executable>` from a terminal opened with "Run as administrator" | Windows requires administrator rights. |

spy never refuses to run your program. If something it needs is missing, it runs the program anyway, records everything it still can, and tells you afterwards what was not recorded and how to enable it.

## Decrypted web traffic

Most programs work with no setup: spy shows you their HTTPS traffic in the clear, and nothing on your system is changed.

Some programs do not accept this by default. When that happens, spy tells you, and you can rerun with one of two flags:

- **`--env`** redirects the program's API endpoints through spy. Works for programs that read their endpoint from an environment variable.
- **`--cert`** makes your system trust spy's certificate for the length of the run, and removes it when the run ends. While the run lasts, the trust applies to your whole machine, which is why it is opt-in. On Linux this flag needs `sudo`.

Traffic that is not decrypted is still recorded as network activity.

## Credentials

By default, credential headers (`Authorization`, `Cookie`, `Set-Cookie`, `x-api-key`, and similar) are hidden in recorded web requests. Bodies are never altered. Use `--no-redact` to record everything exactly as sent.

The log file is readable only by you. It can contain sensitive data from the program you ran, so treat it accordingly.

## Config files

Optional. A config file sets how spy runs one particular program, so you do not have to repeat flags.

Create `~/.config/spy/<executable name>.toml` (on Windows, `%AppData%\spy\<executable name>.toml`):

```toml
# ~/.config/spy/sometool.toml
args     = ["--verbose"]        # extra arguments for the program
capture  = "intercept"          # web traffic: "intercept", "env", "cert", or "off"
redact   = true                 # false records credentials as sent
redact_headers = ["x-custom-secret"]

# what to record, all true by default
disk            = true
network         = true
network_content = true
syscalls        = true          # raw system calls (Linux)

[set_env]                       # extra environment for the program
FOO = "bar"

[endpoints]                     # used with capture = "env"
SOMETOOL_API_URL = "https://api.example.com/v1"
```

## The log

One JSON object per line, so it works with `jq`, log pipelines, and anything else that reads JSON Lines.

```json
{"v":1,"run_id":"a1b2c3d4","seq":42,"time":"2026-11-12T19:00:00.123Z","source":"http","type":"http.request","request_id":"q7","data":{"method":"POST","url":"https://api.example.com/v1/items","headers":{"Authorization":"[redacted]"},"body":"{\"name\":\"widget\"}"}}
```

| Source | Event types |
|---|---|
| `http` | `http.request`, `http.response.start`, `http.response.chunk`, `http.response.end`, `http.ws.message`, `http.error` |
| `network` | `net.connect`, `net.accept`, `net.bind`, `net.listen`, `net.send`, `net.recv`, `net.close`, `dns.query`, `dns.response`, and more |
| `disk` | `file.open`, `file.close`, `file.create`, `file.read`, `file.write`, `file.rename`, `file.delete`, `file.copy`, `file.link`, `file.chmod`, `file.chown`, and more |
| `process` | `process.fork`, `process.exec`, `process.exit` |
| `syscall` | `syscall` (Linux: every disk and network system call, as made) |
| `spy` | `run.start`, `run.end`, `spy.error` |

- Events are written as they happen, so you can follow a run live.
- `run.start` lists exactly what was being recorded in that run.
- Every event carries the process that caused it.

Some examples:

```
# every URL the program contacted
jq -r 'select(.type=="http.request") | .data.url' run.jsonl

# every file it deleted
jq -r 'select(.type=="file.delete") | .data.path' run.jsonl

# every program it launched
jq -r 'select(.type=="process.exec") | .data.argv | join(" ")' run.jsonl
```

## spyview

`spyview` is the terminal viewer for spy logs.

```
spyview                     # open the newest log in this folder
spyview run.jsonl           # open a specific log
spyview --tail run.jsonl    # follow a log live while spy is writing it
```

- **Overview:** what ran, what was recorded, and anything spy could not capture.
- **HTTP:** one row per request, with the full request and the response body put back together.
- **Network:** one row per connection, with what was sent and received. DNS has its own list.
- **Disk:** one row per file, with everything that was done to it.
- **Processes:** the tree of programs that were launched.
- **Events:** everything, in order.

What you can do in it:

- **Read content decoded.** JSON, event streams, compressed bodies, forms, and tokens are shown readable. One key switches between decoded, raw, and hex.
- **Follow a conversation.** Every row of a web request shows where it went; one key narrows the list to a single request and its response.
- **Filter** by kind of event, process, host, path, text, or time.
- **Search** every tab, including inside decoded content.
- **Mark and label** events you care about, and export them.
- **Group** events by type, process, host, and more.
- **Jump** from any event to its request, connection, file, or process.
- **Select text with the mouse** to copy it.
- **Follow live** with `--tail`.
- Works with keyboard and mouse. Press `?` for all keys.

spyview never changes a log file.

## Limits

- spy sees the program it launches and that program's children. Work a program hands to a background service that was already running is not visible.
- Encrypted traffic that is not web traffic (SSH, for example) is recorded but cannot be decrypted.
- On macOS, spy reports which files were opened for reading rather than each individual read.
- On Windows, the content of network traffic that is not web traffic is not recorded; its addresses and sizes are.

## Platforms

- **macOS** 13 or later, Apple silicon and Intel.
- **Linux**, x86-64 and ARM64.
- **Windows** 10 (1809) or later, x86-64 and ARM64. Windows support is new; please report anything that does not work.

## License

spy and spyview are free to use, for any purpose. You may share unmodified copies. You may not modify the software or reverse engineer it. See [LICENSE](LICENSE) for the full terms.
